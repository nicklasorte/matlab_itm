RSS data for Rec.311 Tables VI-1 and VI-2
Distribution disk 3:
Run *.EXE files to write expanded data files.
Contents (all 4 files contain profile data):
 Band1.exe
 Band2.exe
 Band3.exe
 Rssdata.exe