RSS data for Rec.311 Tables VI-1 and VI-2
Distribution disk 2:
Run *.EXE files to write expanded data files.
Contents:
 Band6.exe:    spatial 1.0-2.0 GHz
 Band7.exe:    spatial 2.0-3.0 GHz
 Bands1_3.exe: temporal 30-300 MHz
 Bands4_7.exe: temporal 300-3,000 MHz
