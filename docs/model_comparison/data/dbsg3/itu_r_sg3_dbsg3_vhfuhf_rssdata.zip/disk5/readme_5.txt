RSS data for Rec.311 Tables VI-1 and VI-2
Distribution disk 5:
Run *.EXE files to write expanded data files.
Contents (all 2 files contain profile data):
 Sprofs.exe
 Tprofs.exe
