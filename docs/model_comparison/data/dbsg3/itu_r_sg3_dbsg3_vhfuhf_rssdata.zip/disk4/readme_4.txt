RSS data for Rec.311 Tables VI-1 and VI-2
Distribution disk 4:
Run *.EXE files to write expanded data files.
Contents (all 4 files contain profile data):
 Colorado.exe
 Ebudata.exe
 Itudata.exe
 Ohio.exe
