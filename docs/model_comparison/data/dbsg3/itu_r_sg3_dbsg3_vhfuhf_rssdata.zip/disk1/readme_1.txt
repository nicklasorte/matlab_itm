RSS data for Rec.311 Tables VI-1 and VI-2
Distribution disk 1:
Run *.EXE files to write expanded data files.
Contents:
 Band1.exe: spatial 30-75 MHz
 Band2.exe: spatial 75-150 MHz
 Band3.exe: spatial 150-300 MHz
 Band4.exe: spatial 300-600 MHz
 Band5.exe: spatial 600-1000 MHz
